#include <stdio.h>
// test program
int main(){
	int i=0;
	for(i=0;i<10000000;i++){
	fprintf(stdout,"Hello World -output stream %i\n",i);
	fflush(stdout);
	fprintf(stderr,"Hello World -error stream %i \n",i);
	fflush(stderr);
	}
}
