main(){

  int i=0;
  for(i=0;i<20;i++){
  sleep(2);
  printf("hello world from c %i\n",i);
  }
}
