main(){

  printf("hello world from c\n");

}
